﻿using System;

class Alliance
{
    public string Name { get; set; }
    public int AutonomousWinPoints { get; set; }
    public int AutonomousScore { get; set; }
    public int GoalTriballs { get; set; }
    public int FieldTriballs { get; set; }
    public int ElevationScore { get; set; }

    public Alliance(string name)
    {
        Name = name;
        AutonomousWinPoints = 0;
        AutonomousScore = 0;
        GoalTriballs = 0;
        FieldTriballs = 0;
        ElevationScore = 0;
    }

    public int CalculateTotalScore()
    {
        return AutonomousWinPoints + AutonomousScore + (GoalTriballs * 5) + (FieldTriballs * 2) + ElevationScore;
    }
}

class Program
{
    static void Main(string[] args)
    {
        Alliance redAlliance = new Alliance("Red");
        Alliance blueAlliance = new Alliance("Blue");

        Console.WriteLine("Robotic - Over Under Calculator\n");

        // Input for Red Alliance
        Console.WriteLine("Red Alliance:");
        Console.Write("Autonomous Win Points: ");
        redAlliance.AutonomousWinPoints = Convert.ToInt32(Console.ReadLine());

        Console.Write("Autonomous Score: ");
        redAlliance.AutonomousScore = Convert.ToInt32(Console.ReadLine());

        Console.Write("Triballs in Goal: ");
        redAlliance.GoalTriballs = Convert.ToInt32(Console.ReadLine());

        Console.Write("Triballs on Field: ");
        redAlliance.FieldTriballs = Convert.ToInt32(Console.ReadLine());

        Console.Write("Elevation Score: ");
        redAlliance.ElevationScore = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine();

        // Input for Blue Alliance
        Console.WriteLine("Blue Alliance:");
        Console.Write("Autonomous Win Points: ");
        blueAlliance.AutonomousWinPoints = Convert.ToInt32(Console.ReadLine());

        Console.Write("Autonomous Score: ");
        blueAlliance.AutonomousScore = Convert.ToInt32(Console.ReadLine());

        Console.Write("Triballs in Goal: ");
        blueAlliance.GoalTriballs = Convert.ToInt32(Console.ReadLine());

        Console.Write("Triballs on Field: ");
        blueAlliance.FieldTriballs = Convert.ToInt32(Console.ReadLine());

        Console.Write("Elevation Score: ");
        blueAlliance.ElevationScore = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine();

        // Displaying Total Scores
        Console.WriteLine($"Red Alliance Total Score: {redAlliance.CalculateTotalScore()}");
        Console.WriteLine($"Blue Alliance Total Score: {blueAlliance.CalculateTotalScore()}");
    }
}
