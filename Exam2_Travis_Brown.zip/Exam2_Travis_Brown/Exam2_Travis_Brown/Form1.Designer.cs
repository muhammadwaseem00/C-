﻿namespace Exam2_Travis_Brown
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuComboBox = new ComboBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            subtot = new TextBox();
            taxtxt = new TextBox();
            tipstxt = new TextBox();
            totaltxt = new TextBox();
            menu = new Label();
            Clrbill = new Button();
            addbill = new Button();
            SuspendLayout();
            // 
            // menuComboBox
            // 
            menuComboBox.FormattingEnabled = true;
            menuComboBox.Location = new Point(187, 53);
            menuComboBox.Name = "menuComboBox";
            menuComboBox.Size = new Size(121, 23);
            menuComboBox.TabIndex = 0;
            menuComboBox.SelectedIndexChanged += menuComboBox_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(95, 113);
            label1.Name = "label1";
            label1.Size = new Size(58, 15);
            label1.TabIndex = 1;
            label1.Text = "Sub Total";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(95, 153);
            label2.Name = "label2";
            label2.Size = new Size(26, 15);
            label2.TabIndex = 2;
            label2.Text = "Tax";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(95, 195);
            label3.Name = "label3";
            label3.Size = new Size(29, 15);
            label3.TabIndex = 3;
            label3.Text = "Tips";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(95, 239);
            label4.Name = "label4";
            label4.Size = new Size(34, 15);
            label4.TabIndex = 4;
            label4.Text = "Total";
            // 
            // subtot
            // 
            subtot.Location = new Point(187, 110);
            subtot.Name = "subtot";
            subtot.Size = new Size(121, 23);
            subtot.TabIndex = 5;
            // 
            // taxtxt
            // 
            taxtxt.Location = new Point(187, 153);
            taxtxt.Name = "taxtxt";
            taxtxt.Size = new Size(121, 23);
            taxtxt.TabIndex = 6;
            // 
            // tipstxt
            // 
            tipstxt.Location = new Point(187, 195);
            tipstxt.Name = "tipstxt";
            tipstxt.Size = new Size(121, 23);
            tipstxt.TabIndex = 7;
            // 
            // totaltxt
            // 
            totaltxt.Location = new Point(187, 239);
            totaltxt.Name = "totaltxt";
            totaltxt.Size = new Size(121, 23);
            totaltxt.TabIndex = 8;
            // 
            // menu
            // 
            menu.AutoSize = true;
            menu.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            menu.Location = new Point(95, 61);
            menu.Name = "menu";
            menu.Size = new Size(39, 15);
            menu.TabIndex = 9;
            menu.Text = "Menu";
            // 
            // Clrbill
            // 
            Clrbill.Location = new Point(116, 306);
            Clrbill.Name = "Clrbill";
            Clrbill.Size = new Size(116, 25);
            Clrbill.TabIndex = 10;
            Clrbill.Text = "ClearBill";
            Clrbill.UseVisualStyleBackColor = true;
            Clrbill.Click += Clrbill_Click;
            // 
            // addbill
            // 
            addbill.Location = new Point(266, 308);
            addbill.Name = "addbill";
            addbill.Size = new Size(75, 23);
            addbill.TabIndex = 11;
            addbill.Text = "Add";
            addbill.UseVisualStyleBackColor = true;
            addbill.Click += addbill_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(addbill);
            Controls.Add(Clrbill);
            Controls.Add(menu);
            Controls.Add(totaltxt);
            Controls.Add(tipstxt);
            Controls.Add(taxtxt);
            Controls.Add(subtot);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(menuComboBox);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox menuComboBox;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox subtot;
        private TextBox taxtxt;
        private TextBox tipstxt;
        private TextBox totaltxt;
        private Label menu;
        private Button Clrbill;
        private Button addbill;
    }
}