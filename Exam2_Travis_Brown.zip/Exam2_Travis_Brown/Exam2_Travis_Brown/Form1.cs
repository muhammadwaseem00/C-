using System;
using System.Data.Odbc;
using System.Windows.Forms;

namespace Exam2_Travis_Brown
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeMenu();
        }
        private const string ConnectionString = "Driver={Microsoft Access Driver (*.mdb, *.accdb)}; Dbq=D:\\Database11.mdb; Trusted_Connection=Yes;";


        private decimal subtotal = 0;
        private decimal taxRate = 0.1M; // 10% tax rate
        private decimal tipsRate = 0.15M; // 15% tips rate
        private List<string> billItems = new List<string>();
        private List<decimal> billPrices = new List<decimal>();
        private void InitializeMenu()
        {
            menuComboBox.Items.Clear();
            try
            {
                using (OdbcConnection connection = new OdbcConnection(ConnectionString))
                {
                    connection.Open();
                    OdbcCommand command = new OdbcCommand("SELECT * FROM MenuItems", connection);
                    OdbcDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string category = reader["Category"].ToString();
                        string itemName = reader["ItemName"].ToString();
                        decimal itemPrice = Convert.ToDecimal(reader["Price"]);

                        menuComboBox.Items.Add($"{category}: {itemName} - ${itemPrice}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading menu: {ex.StackTrace}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
            }

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void menuComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedMenuItem = menuComboBox.SelectedItem?.ToString();
            if (!string.IsNullOrEmpty(selectedMenuItem))
            {
                decimal itemPrice = decimal.Parse(selectedMenuItem.Split('-')[1].Replace("$", ""));
                subtotal += itemPrice;
                UpdateBill();
            }
        }
        private void UpdateBill()
        {
            // Update the GUI with current bill details
            decimal tax = subtotal * taxRate;
            decimal tips = (subtotal > 6) ? subtotal * tipsRate : 0;
            decimal total = subtotal + tax + tips;

            subtot.Text = subtotal.ToString("C");
            taxtxt.Text = tax.ToString("C");
            tipstxt.Text = tips.ToString("C");
            totaltxt.Text = total.ToString("C");
        }

        private void Clrbill_Click(object sender, EventArgs e)
        {
            // Clear the bill
            subtotal = 0;
            UpdateBill();
        }

        private void addbill_Click(object sender, EventArgs e)
        {
            try
            {
                // Check if an item is selected
                if (menuComboBox.SelectedItem != null)
                {
                    // Extract information from the selected item
                    string selectedItem = menuComboBox.SelectedItem.ToString();
                    string[] itemParts = selectedItem.Split(':');
                    string itemName = itemParts[1].Split('-')[0].Trim();
                    decimal itemPrice = decimal.Parse(itemParts[1].Split('-')[1].Replace("$", "").Trim());

                    // Add the item to the bill (you need to define your bill structure)
                    // For example, you might have a List<string> to store items in the bill
                    // You can also store prices in a List<decimal> for each corresponding item
                    // Update your bill structure based on your requirements

                    // Assuming you have defined a List<string> named 'billItems' and a List<decimal> named 'billPrices'
                    billItems.Add(itemName);
                    billPrices.Add(itemPrice);

                    // Update the subtotal
                    decimal subtotal = billPrices.Sum();
                    subtot.Text = subtotal.ToString("C");

                    // Update the tax
                    decimal tax = subtotal * taxRate;
                    taxtxt.Text = tax.ToString("C");

                    // Update the total
                    decimal total = subtotal + tax;
                    totaltxt.Text = total.ToString("C");
                }
                else
                {
                    MessageBox.Show("Please select an item from the menu.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding item to the bill: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}