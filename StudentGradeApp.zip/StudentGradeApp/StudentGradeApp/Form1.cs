﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using StudentGradeApp.DAL;
using StudentGradeApp.BLL;
namespace StudentGradeApp
{
    public partial class Form1 : Form
    {
        private readonly StudentGradeRepository gradeRepository;
        private readonly GradeProcessor gradeProcessor;
        public Form1()
        {
            InitializeComponent();

            // Specify the path to the XML file
            string xmlFilePath = @"C:\Program Files (x86)\IIS Express\studentGrades.xml";

            // Initialize the Data Access Layer and Business Logic Layer
            gradeRepository = new StudentGradeRepository(xmlFilePath);
            gradeProcessor = new GradeProcessor();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Read and parse the grades from the XML file
                var studentGrades = gradeRepository.ReadStudentGrades();

                // Process the grades and display the results
                gradeProcessor.ProcessGrades(studentGrades);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
