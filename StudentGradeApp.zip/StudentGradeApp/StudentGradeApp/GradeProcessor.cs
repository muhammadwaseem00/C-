﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace StudentGradeApp.BLL
{  
    public class GradeProcessor
    {
        private Form1 form; // Reference to Form1

        public GradeProcessor(Form1 form)
        {
            this.form = form;
        }

        public void ProcessGrades(XElement studentGrades)
        {
            var grades = studentGrades.Elements("grade").Select(x => (double)x).ToList();

            if (grades.Count == 0)
            {
                form.DisplayResults("No grades found.");
                return;
            }

            double lowestGrade = grades.Min();
            double highestGrade = grades.Max();
            double averageGrade = grades.Average();

            form.DisplayResults($"Lowest Grade: {lowestGrade}");
            form.DisplayResults($"Highest Grade: {highestGrade}");
            form.DisplayResults($"Average Grade: {averageGrade}");
        }
    }
}
