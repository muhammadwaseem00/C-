﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace StudentGradeApp.BLL
{  
    public class GradeProcessor
    {
    public void ProcessGrades(XElement studentGrades)
    {
        var grades = studentGrades.Elements("grade").Select(x => (double)x).ToList();

        if (grades.Count == 0)
        {
            Console.WriteLine("No grades found.");
            return;
        }

        double lowestGrade = grades.Min();
        double highestGrade = grades.Max();
        double averageGrade = grades.Average();

        DisplayResults(lowestGrade, highestGrade, averageGrade);
    }

    private void DisplayResults(double lowestGrade, double highestGrade, double averageGrade)
    {
        Console.WriteLine($"Lowest Grade: {lowestGrade}");
        Console.WriteLine($"Highest Grade: {highestGrade}");
        Console.WriteLine($"Average Grade: {averageGrade}");
    }
}
}
