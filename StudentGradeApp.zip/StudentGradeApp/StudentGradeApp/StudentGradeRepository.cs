﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace StudentGradeApp.DAL
{
    public class StudentGradeRepository
    {
        private readonly string xmlFilePath;

        public StudentGradeRepository(string filePath)
        {
            xmlFilePath = filePath;
        }

        public XElement ReadStudentGrades()
        {
            return XElement.Load(xmlFilePath);
        }
    }
}
