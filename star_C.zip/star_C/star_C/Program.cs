﻿using System;

class DisplayPatterns
{
    static void Main()
    {
      
        for (int i = 10; i >= 1; i--)
        {
            for (int j = 10; j > i; j--)
            {
                Console.Write(" ");
            }
            for (int k = 1; k <= i; k++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
        }
    }
}
