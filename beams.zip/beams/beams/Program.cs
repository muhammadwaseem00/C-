﻿using System;

class Program
{
    static void Main()
    {
        // User input for beam configurations
        Console.Write("Enter the number of beam configurations to investigate: ");
        int numConfigurations = int.Parse(Console.ReadLine());

        for (int config = 1; config <= numConfigurations; config++)
        {
            Console.WriteLine($"\nConfiguration {config}");

            // User input for beam dimensions
            double length, width, height;
            Console.Write("Enter Beam length in inches: ");
            length = double.Parse(Console.ReadLine());

            Console.Write("Enter Beam width in inches: ");
            width = double.Parse(Console.ReadLine());

            Console.Write("Enter Beam height in inches: ");
            height = double.Parse(Console.ReadLine());

            // Module 2: Use aluminum as the beam material
            double modulus = 29000000;  // Modulus for aluminum (in psi)

            // Applied load input
            double appliedLoad;
            Console.Write("Enter Tip Load(lbs): ");
            appliedLoad = double.Parse(Console.ReadLine());

            // Perform calculations
            double areaMomentOfInertia = CalculateAreaMomentOfInertia(width, height);
            double bendingStiffness = modulus * areaMomentOfInertia;
            double tipDisplacement = CalculateTipDisplacement(length, appliedLoad, modulus, areaMomentOfInertia);

            // Display results
            DisplayOutput(length, width, height, modulus, areaMomentOfInertia, bendingStiffness, tipDisplacement);
        }
    }

    static double CalculateAreaMomentOfInertia(double width, double height)
    {
        // Calculate and return the area moment of inertia
        return (width * Math.Pow(height, 3)) / 12.0;
    }

    static double CalculateTipDisplacement(double length, double appliedLoad, double modulus, double areaMomentOfInertia)
    {
        // Calculate and return the tip displacement
        return -appliedLoad * Math.Pow(length, 3) / (3 * modulus * areaMomentOfInertia);
    }

    static void DisplayOutput(double length, double width, double height, double modulus,
                              double areaMomentOfInertia, double bendingStiffness, double tipDisplacement)
    {
        // Display the output table
        Console.WriteLine("\nLength\t\tb(in)\t\t\t\th(in)\t\t\tE(psi)\t\t\tI(in^4)\t\t\tEI (PSI-in^4)\t\tTip Displacement(in)");
        Console.WriteLine($"{length}\t\t{width}\t\t\t{height}\t\t\t{modulus}\t\t\t{areaMomentOfInertia:F2}\t\t\t{bendingStiffness:F2}\t\t\t{tipDisplacement:F2}\n");
    }
}
