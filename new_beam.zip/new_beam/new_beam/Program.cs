﻿using System;

class Program
{
    static void Main()
    {
        // Module 2: Collect inputs
        Console.Write("Enter the number of beam configurations to investigate: ");
        int numberOfConfigurations = int.Parse(Console.ReadLine());

        for (int configIndex = 1; configIndex <= numberOfConfigurations; configIndex++)
        {
            Console.WriteLine($"\nBeam Configuration {configIndex}:");

            Console.Write("Enter the beam length (l): ");
            double length = double.Parse(Console.ReadLine());

            Console.Write("Enter the beam width (b): ");
            double width = double.Parse(Console.ReadLine());

            Console.Write("Enter the beam height (h): ");
            double height = double.Parse(Console.ReadLine());

            // Module 3: Material choice (Aluminum for Module 2, Aluminum or Titanium from Module 3)
            string material = (configIndex == 1) ? "Aluminum" : GetMaterialChoice();

            // Module 3: Validate inputs
            if (!ValidateInputs(length, width, height, material))
            {
                Console.WriteLine("Invalid inputs. Please enter valid values.");
                configIndex--; // Re-enter inputs for the current configuration
                continue;
            }

            // Module 4: Calculate and display results
            double areaMomentOfInertia = CalculateAreaMomentOfInertia(width, height);
            double bendingStiffness = CalculateBendingStiffness(areaMomentOfInertia, material);
            double tipDisplacement = CalculateTipDisplacement(length, bendingStiffness);

            // Module 6: Display results
            DisplayResults(configIndex, length, width, height, material, areaMomentOfInertia, bendingStiffness, tipDisplacement);
        }
    }

    // Helper methods for calculations and user interaction

    static string GetMaterialChoice()
    {
        Console.Write("Choose material (Aluminum or Titanium): ");
        return Console.ReadLine();
    }

    static bool ValidateInputs(double length, double width, double height, string material)
    {
        // Add validation logic here based on specific criteria
        // For simplicity, a placeholder validation is used in this example.
        return length > 0 && width > 0 && height > 0 && (material == "Aluminum" || material == "Titanium");
    }

    static double CalculateAreaMomentOfInertia(double width, double height)
    {
        return (width * Math.Pow(height, 3)) / 12.0;
    }

    static double CalculateBendingStiffness(double areaMomentOfInertia, string material)
    {
        // For simplicity, a placeholder modulus value is used.
        double modulus = (material == "Aluminum") ? 10.0e6 : 15.0e6;
        return areaMomentOfInertia * modulus;
    }

    static double CalculateTipDisplacement(double length, double bendingStiffness)
    {
        double force = 1000.0; // Placeholder value for force (to be obtained from user in practice)
        return (force * Math.Pow(length, 3)) / (3 * bendingStiffness);
    }

    static void DisplayResults(int configIndex, double length, double width, double height, string material, double areaMomentOfInertia, double bendingStiffness, double tipDisplacement)
    {
        /* Console.WriteLine($"\nResults for Beam Configuration {configIndex}:");
         Console.WriteLine($"Beam Length (l): {length} units");
         Console.WriteLine($"Beam Width (b): {width} units");
         Console.WriteLine($"Beam Height (h): {height} units");
         Console.WriteLine($"Material: {material}");
         Console.WriteLine($"Area Moment of Inertia (I): {areaMomentOfInertia} units^4");
         Console.WriteLine($"Bending Stiffness (EI): {bendingStiffness} units^5");
         Console.WriteLine($"Tip Displacement: {tipDisplacement} units");*/
        Console.WriteLine($"Configuration\tLength (l)\tWidth (b)\tHeight (h)\tMaterial\tI\tBending Stiffness (EI)\tTip Displacement");
        Console.WriteLine($"{configIndex}\t{length}\t{width}\t{height}\t{material}\t{areaMomentOfInertia}\t{bendingStiffness}\t{tipDisplacement}");
    }
}
