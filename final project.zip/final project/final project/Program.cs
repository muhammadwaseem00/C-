﻿using System;
using System.IO;

class Student
{
    public int Grade { get; set; }
}

class Program
{
    static void Main()
    {
        // Create arrays to store data
        Student[] studentsArray = new Student[20]; // Assuming 20 grades will be read
        int[] gradeDistribution = new int[101]; // Assuming grades range from 0 to 100

        // Call GetDataFromFile function to read file contents into the studentsArray
        GetDataFromFile("C:\\Users\\mshee\\source\\repos\\final project\\final project\\input.txt", studentsArray);

        // Call CalcResults function to compute lowest, highest, and average grades
        CalcResults(studentsArray);

        // Call DisplayGradeDistribution function to determine grade distribution and display results
        DisplayGradeDistribution(studentsArray, gradeDistribution);
    }

    // Function to read file contents into array of Students
    static void GetDataFromFile(string fileName, Student[] studentsArray)
    {
        // Read file contents
        string[] grades = File.ReadAllText(fileName).Split(' ');

        // Populate studentsArray with grades from the file
        for (int i = 0; i < grades.Length; i++)
        {
            studentsArray[i] = new Student { Grade = int.Parse(grades[i]) };
        }
    }

    // Function to compute lowest, highest, and average grades
    static void CalcResults(Student[] studentsArray)
    {
        // Initializing variables
        int sum = 0;
        int lowest = studentsArray[0].Grade;
        int highest = studentsArray[0].Grade;

        // Calculating sum, lowest, and highest grades
        foreach (Student student in studentsArray)
        {
            sum += student.Grade;

            if (student.Grade < lowest)
                lowest = student.Grade;

            if (student.Grade > highest)
                highest = student.Grade;
        }

        // Calculating average grade
        double average = (double)sum / studentsArray.Length;

        // Displaying results
        Console.WriteLine($"Lowest grade: {lowest}");
        Console.WriteLine($"Highest grade: {highest}");
        Console.WriteLine($"Average grade: {average:F2}");
    }

    // Function to determine grade distribution and display results
    static void DisplayGradeDistribution(Student[] studentsArray, int[] gradeDistribution)
    {
        // Counting grade distribution
        foreach (Student student in studentsArray)
        {
            gradeDistribution[student.Grade]++;
        }

        // Displaying grade distribution
        for (int i = 0; i < gradeDistribution.Length; i++)
        {
            if (gradeDistribution[i] > 0)
            {
                Console.WriteLine($"Grade {i}: {gradeDistribution[i]} students");
            }
        }
    }
}
