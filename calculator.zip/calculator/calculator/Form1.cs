namespace calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string displayValue = "0"; // To store the displayed value
        double currentValue, lastValue;
        char lastOperation = ' '; // To store the last operation performed
        bool decimalFlag = false; // Flag for decimal entry

        // Event Handler for Number Buttons (0-9)
        private void Number_Click(object sender, EventArgs e)
        {
            if (displayValue == "0")
                displayValue = ""; // Ignore leading zeros

            Button button = (Button)sender;
            displayValue += button.Text;
            display.Text = displayValue; // Display the entered number
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            displayValue = "0";
            display.Text = displayValue;
            decimalFlag = false;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (!decimalFlag)
            {
                displayValue += ".";
                display.Text = displayValue;
                decimalFlag = true;
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            lastOperation = Convert.ToChar(button.Text);
            lastValue = Convert.ToDouble(displayValue);
            displayValue = "0";
            display.Text = displayValue;
            decimalFlag = false;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            currentValue = Convert.ToDouble(displayValue);
            if (lastOperation == '+')
            {
                currentValue = lastValue + currentValue;
                displayValue = currentValue.ToString();
                display.Text = displayValue;
            }
            // Implement other operations in a similar manner for subtraction, multiplication, and division.
            decimalFlag = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (displayValue == "0")
                displayValue = ""; // Ignore leading zeros

            Button button = (Button)sender;
            displayValue += button.Text;
            display.Text = displayValue; // Display the entered number
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (displayValue == "0")
                displayValue = ""; // Ignore leading zeros

            Button button = (Button)sender;
            displayValue += button.Text;
            display.Text = displayValue; // Display the entered number
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (displayValue == "0")
                displayValue = ""; // Ignore leading zeros

            Button button = (Button)sender;
            displayValue += button.Text;
            display.Text = displayValue; // Display the entered number
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (displayValue == "0")
                displayValue = ""; // Ignore leading zeros

            Button button = (Button)sender;
            displayValue += button.Text;
            display.Text = displayValue; // Display the entered number
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (displayValue == "0")
                displayValue = ""; // Ignore leading zeros

            Button button = (Button)sender;
            displayValue += button.Text;
            display.Text = displayValue; // Display the entered number
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (displayValue == "0")
                displayValue = ""; // Ignore leading zeros

            Button button = (Button)sender;
            displayValue += button.Text;
            display.Text = displayValue; // Display the entered number
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (displayValue == "0")
                displayValue = ""; // Ignore leading zeros

            Button button = (Button)sender;
            displayValue += button.Text;
            display.Text = displayValue; // Display the entered number
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (displayValue == "0")
                displayValue = ""; // Ignore leading zeros

            Button button = (Button)sender;
            displayValue += button.Text;
            display.Text = displayValue; // Display the entered number
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (displayValue == "0")
                displayValue = ""; // Ignore leading zeros

            Button button = (Button)sender;
            displayValue += button.Text;
            display.Text = displayValue; // Display the entered number
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (displayValue == "0")
                displayValue = ""; // Ignore leading zeros

            Button button = (Button)sender;
            displayValue += button.Text;
            display.Text = displayValue; // Display the entered number
        }
    }
}